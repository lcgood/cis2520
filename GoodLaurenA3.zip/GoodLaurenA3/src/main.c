/*
Author: Lauren Good 0871905
Project: Assignment 3
Course: CIS*2520
Last Modified: Aug 2, 2016
*/

#include "fileManager.h"

int main (int argc, char ** argv)
{
	if(argc >= 2)
	{
		char * currentPath = malloc(sizeof(char)*150);
		char * startingPath = malloc(sizeof(char)*150);
		strcpy(currentPath,argv[1]);
		strcpy(startingPath,argv[1]);
		Tree * tree = createTree(&compare,&destroyFile);
		bool success = readDirectories(tree, currentPath);
		if(success)
		{
			printList(tree);
			printf("\nWelcome to file manager.\n");
			int input = -1;
			char* response = malloc(sizeof(char)*10);
			char * oldName = malloc(sizeof(char)*20);
			char * newName = malloc(sizeof(char)*20);
			char * temp = malloc(sizeof(char)*150);
			while(input != 7)
			{
				printPath(currentPath);
				printf("Menu (please enter the corresponding number)\n");
				printf("1. Delete\n");
				printf("2. Change Directory\n");
				printf("3. Rename\n");
				printf("4. Find\n");
				printf("5. Print\n");
				printf("6. Move File\n");
				printf("7. Exit\n");
				fgets(response,10,stdin);
				input = atoi(response);
				if(input < 1 || input > 7)
				{
					printf("Invalid input. Please try again.\n");
				}
				//done
				else if(input == 1)
				{
					printf("Enter the file to be deleted:\n");
					fgets(oldName,20,stdin);
					if(oldName[strlen(oldName)-1] == '\n') oldName[strlen(oldName)-1] = '\0';
					strcpy(temp,currentPath);
					strcat(temp,oldName);
					File * tempFile = getFile(temp,tree);
					if(tempFile != NULL)
					{
						if(tempFile->isDir){
							bool valid = false;
							char choice;
							while(!valid)
							{
								printf("%s is a directory. If you delete, all subdirectories will also be deleted. Continue? [y/n]\n", oldName);
								choice = fgetc(stdin);
								// to account for the newline
								fgetc(stdin);
								if(choice == 'y' || choice == 'Y' || choice == 'n' || choice == 'N') valid = true;
								else printf("%c is not a valid choice\n", choice);
							}
							if(choice == 'y' || choice == 'Y')
							{
								deleteAllFilesContaining(oldName,tree);
								printf("Success.\n");
							}
							else printf("Canceling delete.\n");
						}
						else
						{
							removeNode(tree,(void*) tempFile);
							printf("Success.\n");
						}

					}
					else printf("%s could not be found\n",oldName);
				}
				//done
				else if(input == 2)
				{
					printf("Enter the directory you'd like to move to or '..' to move up a directory:\nNote: Please do not include the '/' as a first or last character.\n");
					fgets(oldName,20,stdin);
					if(strstr(oldName,"..")!=NULL)
					{
						//move up
						if(strcmp(startingPath,currentPath)==0) printf("Cannot go above starting directory.\n");
						else
						{
							char ** pathAndFile = parsePath(currentPath);
							if(pathAndFile[0][strlen(pathAndFile[0])-2] == '/') pathAndFile[0][strlen(pathAndFile[0])-2] = '\0';
							strcpy(currentPath,pathAndFile[0]);
							free(pathAndFile[0]);
							free(pathAndFile[1]);
							free(pathAndFile);
						}
					}
					else
					{
						//move to specified dir
						if(oldName[strlen(oldName)-1] == '\n') oldName[strlen(oldName)-1] = '\0';
						strcpy(temp,currentPath);
						strcat(temp,oldName);
						File * tempFile = getFile(temp,tree);
						if(tempFile == NULL)
						{
							printf("Invalid directory. %s cannot be found\n",temp);
						}
						else
						{
							if(!tempFile->isDir) printf("Cannot move into a file. Please chose a directory\n");
							else
							{
								strcpy(currentPath,temp);
								if(oldName[strlen(oldName)-2] != '/') strcat(currentPath, "/");
							}
						}
					}
				}
				//done
				else if(input == 3)
				{
					bool valid = false;
					char ** pathAndFile = NULL;
					File * file = NULL;
					while(!valid)
					{
						printf("Note: Please do not include the '/' as a first or last character.\n\n");
						printf("Enter the old name:\n");
						fgets(oldName,20,stdin);
						if(oldName[strlen(oldName)-1] == '\n') oldName[strlen(oldName)-1] = '\0';
						strcpy(temp,currentPath);
						strcat(temp,oldName);
						pathAndFile = parsePath(temp);
						file = getFile(temp,tree);
						if(file == NULL)
						{
							valid = false;
							printf("Cannot find record %s\n",temp);
						}
						else valid = true;
					}
					printf("\nNote: do not include path\n");
					printf("Enter the new name:\n");
					fgets(newName,20,stdin);
					if(newName[strlen(newName)-1] == '\n') newName[strlen(newName)-1] = '\0';
					char * newPath = malloc(sizeof(char)*150);
					strcpy(newPath,pathAndFile[0]);
					strcat(newPath,newName);
					
					free(file->path);
					file->path = newPath;
					bool success = renameFile(newName,oldName,tree);
					if(success) printf("Rename successful\n");
					else printf("Error renaming\n");
					
					free(pathAndFile[0]);
					free(pathAndFile[1]);
					free(pathAndFile);
				}
				// done
				else if(input == 4)
				{
					printf("Enter the file you want to find:\n");
					fgets(oldName,20,stdin);
					if(oldName[strlen(oldName)-1] == '\n') oldName[strlen(oldName)-1] = '\0';
					printf("Results:\n");
					findFile(tree,oldName);
				}
				//done
				else if(input == 5)
				{
					printf("What would you like to print? (enter the coresponding number)\n");
					bool valid = false;
					while (!valid)
					{
						printf("1. Print all\n");
						printf("2. Print current directory\n");
						fgets(response,10,stdin);
						input = atoi(response);
						if(input == 1)
						{
							printList(tree);
							valid = true;
						}
						else if(input == 2)
						{
							printCurrentDir(tree, currentPath, currentPath);
							valid = true;
						}
						else
						{
							printf("Invalid choice.\n");
							valid = false;
						}
					}
				}
				else if(input == 6)
				{
					printf("Enter the full path of the file you'd like to move:\n");
					fgets(temp,150,stdin);
					if(temp[strlen(temp)-1] == '\n') temp[strlen(temp)-1] = '\0';
					File * tempFile = getFile(temp,tree);
					char ** result = parsePath(temp);
					char * startName = malloc(sizeof(char)*150);
					char * startPath = malloc(sizeof(char)*150);
					strcpy(startPath,temp);
					strcpy(startName,result[1]);
					bool valid = false;
					if(tempFile == NULL) printf("Error finding file %s\n",temp);
					else
					{
						bool isDir = tempFile->isDir;
						while(!valid)
						{
							printf("Enter the full new path of the file.\n");
							fgets(temp,150,stdin);
							if(temp[strlen(temp)-1] == '\n') temp[strlen(temp)-1] = '\0';
							result = parsePath(temp);
							if(strcmp(result[1],startName) == 0)
							{
								// do not remove trailing '/' if starting dir
								if(result[0][strlen(result[0])-1] == '/' && strcmp(result[0],startingPath) != 0) result[0][strlen(result[0])-1] = '\0';
								File * baseFile = getFile(result[0],tree);
								if(baseFile == NULL && strcmp(result[0],startingPath) != 0) 
								{
									printf("Error %s is not a valid directory\n",result[0]);
									valid = false;
								}
								else
								{
									removeNode(tree, (void*) tempFile);
									addFileToTree(tree,isDir,temp);
									//renameFile(temp+2,startPath,tree);
									valid = true;
								}
							}
							else
							{
								printf("Error. Cannot change the file name during a move.\n");
								valid = false;
							}
						}	
					}
					free(startName);
				}
			}
		}
		destroyTree(tree);
	}
	else printf("Invalid number of arguments\n");
    return 0;
}  