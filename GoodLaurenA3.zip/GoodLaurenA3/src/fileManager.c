/*
Author: Lauren Good 0871905
Project: Assignment 3
Course: CIS*2520
Last Modified: Aug 2, 2016
*/
#include "fileManager.h"

void printPath(char * path)
{
	printf("\nCurrent Path: %s\n", path);
}

void printNode(void * data)
{
    File * temp = (File *) data;
    if(!temp->isDir)printf("File:%s\n",temp->path);
    else printf("Directory:%s\n",temp->path);
}

void printList(Tree * tree)
{
    if(tree != NULL)
    {
        Tree * rightTree = getRightSubtree(tree);
        Tree * leftTree = getLeftSubtree(tree);
        if(leftTree != NULL)printList(leftTree);
        if(getRootData(tree) != NULL) printNode(getRootData(tree));
        if(rightTree != NULL)printList(rightTree);
        free(rightTree);
        free(leftTree);
    }
}

int getNumberOfSlashes(char * str)
{
    int count = 0;
    char * i;
    for(i = str; *i; i++)
    {
        if(*i == '/') count ++;
    }
    return count;
}

void printCurrentDir(Tree * tree, char * dir, char * base)
{
	if(tree != NULL && dir != NULL)
    {
        int currentDirSlashes = getNumberOfSlashes(dir);
        int baseDirSlashes = getNumberOfSlashes(base);
        Tree * rightTree = getRightSubtree(tree);
        Tree * leftTree = getLeftSubtree(tree);
        File * data = (File *)getRootData(tree);
        if(leftTree != NULL)printCurrentDir(leftTree,((File *)getRootData(leftTree))->path,base);
        if(data != NULL && currentDirSlashes == baseDirSlashes && strstr(dir,base) != NULL && strlen(dir) > strlen(base)) 
        {
            char ** temp = parsePath(dir);
            if(data->isDir)printf("Directory: %s\n", temp[1]);
            else printf("File: %s\n",temp[1]);
            free(temp[0]);
            free(temp[1]);
            free(temp);
        }
        if(rightTree != NULL)printCurrentDir(rightTree,((File *)getRootData(rightTree))->path,base);
        free(rightTree);
        free(leftTree);
    }
}

int compare(void * data1, void * data2)
{
    if(data1 == NULL || data2 == NULL) return 0;
    return strcmp(((File*)data1)->path, ((File*)data2)->path);
}

void destroyFile(void * data)
{
    if(data != NULL)
    {
        File * temp = (File *) data;
        free(temp->path);
    }
}

void addFileToTree(Tree * tree, bool isDir, char * path)
{
    if(tree != NULL && path != NULL)
    {
        File * newFile = malloc(sizeof(File));
        newFile->isDir = isDir;
        newFile->path = malloc(sizeof(char)*300);
        strcpy(newFile->path,path);
        addToTree(tree, (void*) newFile);
    }
}

bool readDirectories(Tree * tree, char * dir)
{
    bool opened = true;
    DIR * dp;
    dp = opendir(dir);
    struct dirent * entry;
    char * pathWithFile = malloc(sizeof(char)*300);
    if(dp != NULL)
    {
        entry = readdir(dp);
        while(entry != NULL)
        {
            if (entry != NULL)
            {
                DIR * dp2 = opendir(entry->d_name);
                
                strcpy(pathWithFile,dir);
                strcat(pathWithFile,entry->d_name);
                if(dp2 == NULL) 
                {
                    if(strstr(pathWithFile,"/.")== NULL && strstr(pathWithFile,"...") == NULL) addFileToTree(tree,false,pathWithFile);
                }
                else 
                {
                    if(strstr(pathWithFile,"/.")== NULL && strstr(pathWithFile,"...") == NULL) 
                    {
                    	addFileToTree(tree,true,pathWithFile);
	                    strcat(pathWithFile,"/");
	                    if(!readDirectories(tree,pathWithFile)) opened = false;
	                }
                }
            }
            entry = readdir(dp);
        }
        closedir(dp);
    }
    else
    {
        opened = false;
        printf("Error opening directory %s\n",dir);
    }
    free(pathWithFile);
    return opened;
}



bool renameFile(char * newName, char * oldName, Tree * tree)
{
    bool success = true;
    if(tree != NULL && newName != NULL && oldName != NULL)
    {
        Tree * right = getRightSubtree(tree);
        Tree * left = getLeftSubtree(tree);
        File * data = (File *)getRootData(tree);
        if(left != NULL) success = renameFile(newName,oldName,left);
        if(right != NULL) success = renameFile(newName,oldName,right);
        if(data != NULL) 
        {
            char * subset = strstr(data->path,oldName);
            char * copy = malloc(sizeof(char)* 150);
            
            char * token = malloc(sizeof(char)*150);
            char * newPath = malloc(sizeof(char)*150);
            strcpy(copy,data->path);
            copy[strlen(copy)+1] = '\0';
            if (subset != NULL)
            {
                token = strtok(copy,oldName);
                strcpy(newPath,token);
                strcat(newPath,newName);
                token = strtok(NULL, "/");
                token = strtok(NULL, "");
                strcat(newPath,"/");
                strcat(newPath,token);
                if(strcmp(newPath,data->path) != 0) {
                    success = true;
                }
                free(data->path);
                data->path = newPath;
            }
            else {
                free(newPath);
            }
            free(copy);
        }
        else success = false;
    }
    return success;
    
}

char ** parsePath(char * path)
{
    if(path[strlen(path)-1] == '\n') path[strlen(path)-1] = '\0';
    char * copiedPath = malloc(sizeof(char)* strlen(path)+1);
    strcpy(copiedPath,path);
    char ** pathAndFile = malloc(sizeof(char *) *2);
    pathAndFile[0] = malloc(sizeof(char)*150);
    pathAndFile[1] = malloc(sizeof(char)*20);
    char * token = strtok(copiedPath,"/");
    strcpy(pathAndFile[0],token);
    strcat(pathAndFile[0],"/");
    char * lastToken = malloc(sizeof(char)*20);
    int count = 0;
    while(token != NULL)
    {
       strcpy(lastToken,token);
        token = strtok(NULL,"/");
        if(token != NULL && count != 0)
        {
            strcat(pathAndFile[0],lastToken);
            strcat(pathAndFile[0],"/");
        }
        count ++;
    }
    strcpy(pathAndFile[1],lastToken);

    free(lastToken);
    return pathAndFile;
}

File * getFile(char * path, Tree * tree)
{
	if(tree != NULL && path != NULL)
	{
		if(path[strlen(path)-1] == '\n') path[strlen(path)-1] = '\0';
		File * temp = NULL;
		File * found = NULL;
		Tree * right  = getRightSubtree(tree);
		Tree * left = getLeftSubtree(tree);
		temp = getRootData(tree);
		if(strcmp(temp->path,path) == 0) {

			found = temp;
		}
		if(left != NULL && found == NULL)found = getFile(path,left);
		if(right != NULL && found == NULL)found = getFile(path,right);
		free(right);
		free(left);
		if(found != NULL) return found;
		else return NULL;
	}
	else return NULL;
}

void deleteAllFilesContaining(char * dir, Tree * tree)
{
    if(tree != NULL && dir != NULL)
    {
    	Tree * right = getRightSubtree(tree);
    	Tree * left = getLeftSubtree(tree);
    	File * tempFile = getRootData(tree);
    	if(right != NULL) deleteAllFilesContaining(dir,right);
    	if(left != NULL) deleteAllFilesContaining(dir,left);
    	if(tempFile->path != NULL && strstr(tempFile->path,dir) != NULL) removeNode(tree, (void*)tempFile);
    	free(right);
    	free(left);
    }
}

void findFile(Tree * tree, char * toFind)
{
    if(tree != NULL && toFind != NULL)
    {
        Tree * right = getRightSubtree(tree);
        Tree * left = getLeftSubtree(tree);
        File * tempFile = getRootData(tree);
        if(strstr(tempFile->path,toFind) != NULL) printf("%s\n",tempFile->path);
        if(left != NULL) findFile(left,toFind);
        if(right != NULL) findFile(right,toFind);
        free(right);
        free(left);
    }
}