/*
Author: Lauren Good 0871905
Project: Assignment 3
Course: CIS*2520
Last Modified: Aug 2, 2016
*/
#include "tree.h"

void printNode(Node * node)
{
	if(node != NULL)printf("%d\n",*(int*)node->data);
}

void printTree(Tree * tree)
{
	if(tree != NULL)
	{
	    Tree * left = getLeftSubtree(tree);
	    Tree * right = getRightSubtree(tree);
	    if(left != NULL)printTree(left);
	    printNode(tree->root);
	    if(right != NULL)printTree(right);
	    free(left);
	    free(right);
	}
	else printf("The tree is empty\n");
}

int compare(void* data1, void* data2)
{
	if(data1 == NULL || data2 == NULL) return 0;
	if(*((int*)data1)== *((int*)data2)) return 0;
	else if (*((int*)data1) > *((int*)data2)) return 1;
	else return -1;
}

void destroyData(void * data)
{
	free(data);
}

int main()
{
	Tree * tree = createTree(&compare, &destroyData);
	int * data1 = malloc(sizeof(int));
	*data1 = 1;
	int * data2 = malloc(sizeof(int));
	*data2 = 2;
	int * data3 = malloc(sizeof(int));
	*data3 = 3;
	int * data4 = malloc(sizeof(int));
	*data4 = 4;
	int * data5 = malloc(sizeof(int));
	*data5 = 5;
	int * data6 = malloc(sizeof(int));
	*data6 = 6;
	bool isEmpty = treeIsEmpty(tree);
	if(isEmpty)printf("The tree is empty.\n");
	else printf("The tree is not empty\n");
	addToTree(tree, (void*)data4);
	printf("add to tree\n");
	isEmpty = treeIsEmpty(tree);
	if(isEmpty)printf("The tree is empty.\n");
	else printf("The tree is not empty\n");
	printTree(tree);
	printf("add other elements to tree\n");
	addToTree(tree, (void*)data6);
	addToTree(tree, (void*)data2);
	addToTree(tree, (void*)data1);
	addToTree(tree, (void*)data5);
	addToTree(tree, (void*)data3);
	printTree(tree);
	Node * min = findMin(tree->root);
	printf("Minumum node:\n");
	printNode(min);
	Node * max = findMax(tree->root);
	printf("Maximum node:\n");
	printNode(max);
	printf("Left subtree of root\n");
	Tree * left = getLeftSubtree(tree);
	printTree(left);
	printf("Right subtree of root\n");
	Tree * right = getRightSubtree(tree);
	printTree(right);
    bool inTree = isInTree(tree, (void*)data2);
    if(inTree)printf("2 is in the tree\n");
    else printf("2 is not in the tree\n");

    printf("The height of the tree: %d\n", getHeight(tree,0,0));
    printf("The height of the left subtree: %d\n", getHeight(left,0,0));
    printf("The height of the right subtree: %d\n", getHeight(right,0,0));

    
    printf("remove 2 from tree\n");
    removeNode(tree,(void*) data2);
    printTree(tree);
    printf("Root data: %d\n", *(int*)getRootData(tree));
    bool balanced = isBalanced(tree);
    if(!balanced)printf("the tree is not balanced\n");
    else printf("the tree is balanced\n");

    printf("\nrotate the tree to the right\n");
    tree->root = rotateRight(tree->root);
    balanced = isBalanced(tree);
    if(!balanced)printf("the tree is not balanced\n");
    else printf("the tree is balanced\n");
    
    printf("balancing tree\n");
    balance(tree);
    balanced = isBalanced(tree);
    if(!balanced)printf("the tree is not balanced\n");
    else printf("the tree is balanced\n");
   
    printf("\nrotate the tree to the left\n");
    tree->root = rotateLeft(tree->root);
    balanced = isBalanced(tree);
    if(!balanced)printf("the tree is not balanced\n");
    else printf("the tree is balanced\n");

    printf("balancing tree\n");
    balance(tree);
    balanced = isBalanced(tree);
    if(!balanced)printf("the tree is not balanced\n");
    else printf("the tree is balanced\n");

	destroyTree(tree);
	free(left);
    free(right);
    free(data2);
	return 0;
}