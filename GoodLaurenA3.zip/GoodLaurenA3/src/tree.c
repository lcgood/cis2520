/*
Author: Lauren Good 0871905
Project: Assignment 3
Course: CIS*2520
Last Modified: Aug 2, 2016
*/
#include "tree.h"

Tree * createTree(int(*comparePointer)(void* data1, void* data2), void (*destroyPointer) (void*) ) 
{
    Tree * newTree = malloc(sizeof(Tree));
    newTree->compare = comparePointer;
    newTree->destroy = destroyPointer;
    newTree->root = NULL;
    return newTree;
}

void destroyTree(Tree * toDestroy)
{
    if(toDestroy!= NULL && toDestroy->root != NULL)
    {
        destroyTree(getLeftSubtree(toDestroy));
        destroyTree(getRightSubtree(toDestroy));
        toDestroy->destroy(toDestroy->root->data);
        free(toDestroy->root);
        free(toDestroy);
    }
}

void addToTree(Tree * tree, void * data)
{
    Node * toAdd = malloc(sizeof(Node));
    toAdd->parent = NULL;
    toAdd->right = NULL;
    toAdd->left = NULL;
    toAdd->data = data;
    if(tree->root == NULL) tree->root = toAdd;
    else insert(tree->root, toAdd, tree->compare);
}

void removeNode(Tree * tree, void * data)
{

    if(tree != NULL && tree->root != NULL && tree->compare != NULL && tree->destroy != NULL && data != NULL) 
    {
        (tree->root) = delete(tree->root, data, tree->compare, tree->destroy);
    }
}

bool isInTree(Tree * tree, void * data)
{
    if(tree != NULL && data != NULL)
    {
        Tree * temp;
        bool inLeft = false;
        bool inRight = false;
        if(tree->root != NULL && tree->root->left != NULL) {
            temp = getLeftSubtree(tree);
            inLeft = isInTree(temp,data);
            free(temp);
        }
        if(tree->root != NULL && tree->root->right != NULL) 
        {
            temp = getRightSubtree(tree);
            inRight = isInTree(temp,data);
            free(temp);
        }
        if(inRight || inLeft || tree->root->data == data) return true;
        else return false;
    }
    else return false;
}

bool treeIsEmpty(Tree * tree)
{
    if(tree == NULL || tree->root == NULL || tree->root->data == NULL) return true;
    else return false;
}

Tree * getLeftSubtree(Tree * tree)
{
    if(tree != NULL && tree->root != NULL && tree->root->left != NULL)
    {
        Tree * toReturn = malloc(sizeof(Tree));
        toReturn->compare = tree->compare;
        toReturn->destroy = tree->destroy;
        toReturn->root = tree->root->left;
        return toReturn;
    }
    else return NULL;
}

Tree * getRightSubtree(Tree * tree)
{
    if(tree != NULL && tree->root != NULL && tree->root->right != NULL)
    {
        Tree * toReturn = malloc(sizeof(Tree));
        toReturn->compare = tree->compare;
        toReturn->destroy = tree->destroy;
        toReturn->root = tree->root->right;
        return toReturn;
    }
    else return NULL;
}

void * getRootData(Tree * tree)
{
    if(tree != NULL && tree->root != NULL && tree->root->data != NULL) return(tree->root->data);
    else return NULL;
}

void insert(Node * root, Node * toAdd, int(*comparePointer)(void* data1, void* data2))
{
    if(root != NULL && toAdd != NULL && comparePointer != NULL)
    {
        int returnValue = comparePointer(toAdd->data, root->data);
        if(returnValue >= 0) 
        {
            if(root->right != NULL)insert(root->right,toAdd,comparePointer);
            else 
            {
                root->right = toAdd;
                toAdd->parent = root;
            }
        }
        else if(returnValue < 0)
        {
            if(root->left != NULL)insert(root->left,toAdd,comparePointer);
            else 
            {
                root->left = toAdd;
                toAdd->parent = root;
            }
        }
    }
}

Node * delete(Node * root, void * data,int(*comparePointer)(void* data1, void* data2), void (*destroyPointer) (void*))
{
    if(root != NULL && data != NULL && comparePointer != NULL && destroyPointer != NULL) 
    {
        int returnValue = comparePointer(data, root->data);
        if(returnValue > 0) 
        {
            if(root->right != NULL) 
            {
                root->right = delete(root->right,data,comparePointer,destroyPointer);
                if(root->right != NULL)root->right->parent = root;
                return root;
            }
        }
        else if(returnValue < 0)
        {
            if(root->left != NULL) 
            {
                root->left = delete(root->left,data,comparePointer,destroyPointer);
                if(root->left != NULL)root->left->parent = root;
                return root;
            }
        }
        else
        {
            if(root->right == NULL && root->left == NULL)
            {
                if(root->parent != NULL && root->parent->right != NULL && root->parent->right->data != NULL)
                {
                    bool nodeIsRightChild = (data == root->parent->right->data);
                    if(nodeIsRightChild) root->parent->right = NULL;
                    else root->parent->left = NULL;
                }
                
                free(root);
                return NULL;
            }
            else if(root->right == NULL)
            {
                Node * temp = root->left;
                if(root->parent != NULL && root->parent->right != NULL && root->parent->right->data != NULL)
                {
                    bool nodeIsRightChild = (data == root->parent->right->data);
                    if(nodeIsRightChild) root->parent->right = NULL;
                    else root->parent->left = NULL;
                }
                free(root);
                return(temp);
            }
            else if(root->right == NULL)
            {
                Node * temp = root->left;
                if(root->parent != NULL && root->parent->right != NULL && root->parent->right->data != NULL)
                {
                    bool nodeIsRightChild = (data == root->parent->right->data);
                    if(nodeIsRightChild) root->parent->right = NULL;
                    else root->parent->left = NULL;
                }
                free(root);
                return(temp);
            }
            else if(root->left == NULL)
            {
                Node * temp = root->right;
                if(root->parent != NULL && root->parent->right != NULL && root->parent->right->data != NULL)
                {
                    bool nodeIsRightChild = (data == root->parent->right->data);
                    if(nodeIsRightChild) root->parent->right = NULL;
                    else root->parent->left = NULL;
                }
                free(root);
                return(temp);
            }
            else
            {
                Node * temp = findMax(root->left);
                root->data = memcpy(root->data, temp->data,4);
                root->data = temp->data;
                root->left = delete(root->left, temp->data,comparePointer,destroyPointer);
                return(root);
            }
        }
    }
    return NULL;
}

Node * find(Node * root, void * data, int(*comparePointer)(void* data1, void* data2))
{
    if(root != NULL && data != NULL && comparePointer != NULL)
    {
        int returnValue = 0;
        bool done = false;
        Node * temp = root;
        while(temp != NULL && !done)
        {
            returnValue = comparePointer(data, temp->data);
            if(returnValue == 0) done = true;
            // data is greater than current
            else if(returnValue > 0) temp = temp->right;
            // data is less than current
            else if(returnValue < 0) temp = temp->left;
        }

        if(!done) return NULL;
        else return temp;
    }
    else return NULL;
}

Node * findMin(Node * root)
{
    if(root == NULL) return NULL;
    Node * temp;
    temp = root;
    while(temp->left != NULL)
    {
        temp = temp->left;
    }
    return temp;
}

Node * findMax(Node * root)
{
    if(root == NULL) return NULL;
    Node * temp;
    temp = root;
    while(temp->right != NULL)
    {
        temp = temp->right;
    }
    return temp;
}

bool isEmpty(Node * root)
{
    if(root == NULL ||root->data == NULL) return true;
    else return false;
}

void destroy(Node * root,void (*destroyPointer) (void*))
{
    if(root->right != NULL) destroy(root->right, destroyPointer);
    if(root->left != NULL) destroy(root->left, destroyPointer);
    destroyPointer(root->data);
    free(root);
}

int getHeight(Tree * tree, int lastLargest, int current)
{
    if(tree != NULL)
    {
        Tree * left = getLeftSubtree(tree);
        Tree * right = getRightSubtree(tree);
        if(current > lastLargest) lastLargest = current;
        if(right != NULL) lastLargest = getHeight(right, lastLargest,current+1);
        if(left != NULL) lastLargest = getHeight(left, lastLargest,current+1);
        free(left);
        free(right);
        return lastLargest;
    }
    else return 0;
}

bool isBalanced(Tree * tree)
{
    if(tree != NULL)
    {
        bool balanced = false;
        Tree * right = getRightSubtree(tree);
        Tree * left = getLeftSubtree(tree);
        int rightHeight = getHeight(right,0,0);
        int leftHeight = getHeight(left,0,0);
        balanced = (rightHeight-leftHeight == 1 || rightHeight-leftHeight == 0 || rightHeight-leftHeight == -1);
        if(right != NULL && balanced) balanced = isBalanced(right);
        if(left != NULL && balanced) balanced = isBalanced(left);
        free(right);
        free(left);
        return balanced;
    }
    else return false;
}

void balance(Tree * tree)
{
    if(!isBalanced(tree))
    {
        Tree * right = getRightSubtree(tree);
        Tree * left = getLeftSubtree(tree);
        if(left != NULL) balance(left);
        if(right != NULL) balance(right);
        int rightHeight = getHeight(right,0,0);
        int leftHeight = getHeight(left,0,0);
        if(rightHeight > leftHeight)
        {
            Tree* rightsRightChild = getRightSubtree(right);
            Tree* rightsLeftChild = getLeftSubtree(left);
            rightHeight = getHeight(rightsRightChild,0,0);
            leftHeight = getHeight(rightsLeftChild,0,0);
            // double rotation needed.
            if(leftHeight > rightHeight)
            {
                right->root = rotateRight(right->root);
                tree->root = rotateLeft(tree->root);
            }
            //rotate left
            else if(leftHeight < rightHeight)
            {
                tree->root = rotateLeft(tree->root);
            }
            free(rightsLeftChild);
            free(rightsRightChild);
        }
        else if(rightHeight < leftHeight)
        {
            Tree* leftsRightChild = getRightSubtree(right);
            Tree* leftsLeftChild = getLeftSubtree(left);
            rightHeight = getHeight(leftsRightChild,0,0);
            leftHeight = getHeight(leftsLeftChild,0,0);
            // double rotation needed.
            if(leftHeight < rightHeight)
            {
                left->root = rotateLeft(left->root);
                tree->root = rotateRight(tree->root);
            }
            //rotate right
            else if(leftHeight > rightHeight)
            {
                tree->root = rotateRight(tree->root);
            }
            free(leftsLeftChild);
            free(leftsRightChild);
        }
        free(right);
        free(left);
    }
}

Node * rotateRight(Node * root)
{
    Node * temp;
    if(root != NULL && root->left != NULL)
    {
        //temp will be the new root
        temp = root->left;
        //assign new root's right branch to the current node's left branch
        root->left = root->left->right;
        //change parent pointer to comply with above line
        if(temp->right != NULL) temp->right->parent = root;
        //assign new root's parent to old root's parent
        temp->parent = root->parent;
        //change old root's parent to new root
        root->parent = temp;
        //assign the old root to the new root's left
        temp->right = root;
    }
    return temp;
}

Node * rotateLeft(Node * root)
{
    Node * temp;
    if(root != NULL && root->right != NULL)
    {
        //temp will be the new root
        temp = root->right;
        //assign new root's left branch to the current node's right branch
        root->right = root->right->left;
        //change parent pointer to comply with above line
        if(temp->left != NULL) temp->left->parent = root;
        //assign new root's parent to old root's parent
        temp->parent = root->parent;
        //change old root's parent to new root
        root->parent = temp;
        //assign the old root to the new root's left
        temp->left = root;
    }
    return temp;
}

Node * getRoot(Tree * tree)
{
    return(tree->root);
}