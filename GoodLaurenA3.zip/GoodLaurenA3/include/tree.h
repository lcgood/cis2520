#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct Node{
    struct Node * right;
    struct Node * left;
    struct Node * parent;
    void * data;
} Node;

typedef struct Tree {
    int (*compare)(void * data1, void * data2);
    void (*destroy)(void * data);
    Node * root;
} Tree;

/*
purpose: to create a new binary tree
parameters: a pointer to the compare and destroy functions for the specific data type of the void *
returns: a pointer to the new tree
*/
Tree * createTree(int(*comparePointer)(void* data1, void* data2), void (*destroyPointer) (void*) );
/*
purpose: to destroy all elements within the specified binary tree
parameters: a pointer to the tree to be destroyed
returns: nothing
*/
void destroyTree(Tree * toDestroy);
/*
purpose: to add the specifed data into the tree
parameters: a pointer to the tree, a pointer to the data to be stored in the tree
returns: nothing
*/
void addToTree(Tree * tree, void * data);
/*
purpose: to remove a specific data record from the tree
parameters: a pointer to the tree, a pointer to the data to be removed from the tree
returns: nothing
*/
void removeNode(Tree * tree, void * data);
/*
purpose: to check if a specific data record is in the tree
parameters: a pointer to the tree, a pointer to the data to be checked
returns: true if the record was found, otherwise false
*/
bool isInTree(Tree * tree, void * data);
/*
purpose: to determine if any data records are stored in the tree
parameters: a pointer to the tree
returns: true if there are no records, otherwise false
*/
bool treeIsEmpty(Tree * tree);
/*
purpose: to get the left child subtree from the specifed tree
parameters: a pointer to the tree
returns: a pointer to the left child subtree
*/
Tree * getLeftSubtree(Tree * tree);
/*
purpose: to get the right child subtree from the specifed tree
parameters: a pointer to the tree
returns: a pointer to the right child subtree
*/
Tree * getRightSubtree(Tree * tree);
/*
purpose: to get the data stored within the root of the specified tree
parameters: a pointer to the tree
returns: a void pointer to the data record
*/
void * getRootData(Tree * tree);
/*
purpose: to insert a new Node into the proper subtree of the Node * root
parameters: a pointer to the root Node, a pointer to the Node to be added, a function pointer to the compare function
returns: nothing
*/
void insert(Node * root, Node * toAdd, int(*comparePointer)(void* data1, void* data2));
/*
purpose: to delete a specific data record from the tree
parameters: a pointer to the root Node, a pointer to the specific data, a funtion pointer to the compare function, a function pointer to the destroy function
returns: a Node * to the root
*/
Node * delete(Node * root, void * data,int(*comparePointer)(void* data1, void* data2), void (*destroyPointer) (void*));
/*
purpose: to find and return the Node * that contains the specified data
parameters: a pointer to the root Node, a pointer to the specific data, a function pointer to the compare function
returns: a pointer to the Node that contains the specified data 
*/
Node * find(Node * root, void * data, int(*comparePointer)(void* data1, void* data2));
/*
purpose: to find the Node with the smallest valued data *
parameters: a pointer to the root Node
returns: a pointer to the smallest Node
*/
Node * findMin(Node * root);
/*
purpose: to find the Node with the largest valued data *
parameters: a pointer to the root Node
returns: a pointer to the largest Node
*/
Node * findMax(Node * root);
/*
purpose: to determine if the root Node is empty
parameters: a pointer to the root Node
returns: true if the root is empty, otherwise false
*/
bool isEmpty(Node * root);
/*
purpose: to destroy all of the Node pointers and their internal data *
parameters: a pointer to the root Node, a function pointer to the destroy function
returns: nothing
*/
void destroy(Node * root,void (*destroyPointer) (void*));
/*
purpose: to get the max height of the tree
parameters: a pointer to the tree to be measured, the last largest height, the current height
returns: the int value of the height
*/
int getHeight(Tree * tree, int lastLargest, int current);
/*
purpose: to test if a tree is balanced
parameters: a pointer to the tree to be tested
returns: true if balances, otherwise false
*/
bool isBalanced(Tree * tree);
/*
purpose: to balance the tree
parameters: a pointer to the tree to be balanced
returns: nothing
*/
void balance(Tree * tree);
/*
purpose: to rotate the subtree to the right
parameters: a pointer to the root Node
returns: a pointer to the new root
*/
Node * rotateRight(Node * root);
/*
purpose: to rotate the subtree to the left
parameters: a pointer to the root Node
returns: a pointer to the new root
*/
Node * rotateLeft(Node * root);
/*
purpose: to get the root from the tree
parameters: a pointer to the tree to be accessed
returns: a pointer to the root Node
*/
Node * getRoot(Tree * tree);