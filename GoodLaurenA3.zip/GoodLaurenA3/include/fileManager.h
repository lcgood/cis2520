#include <stdio.h>
#include <dirent.h>
#include <regex.h>
#include "tree.h"

typedef struct File{
    char * path;
    bool isDir;
} File;

/*
purpose: to print the current path
parameters: the path to be printed
returns: nothing
*/
void printPath(char * path);
/*
purpose: to print a visual representation of a file
parameters: the pointer to the file
returns: nothing
*/
void printNode(void * data);
/*
purpose: to print all of the files in the tree
parameters: the pointer to the tree to be printed
returns: nothing
*/
void printList(Tree * tree);
/*
purpose: to get the number of slashes in a string
parameters: the string to be analyzed
returns: the number of forward slashes in the string
*/
int getNumberOfSlashes(char * str);
/*
purpose: to print everything in the currect directory
parameters: the pointer to the tree, the current directory, and the base direcory to be searched
returns: nothing
*/
void printCurrentDir(Tree * tree, char * dir, char * base);
/*
purpose: to compare 2 files and determine which is "larger"
parameters: the pointers to 2 files to be compared
returns: 0 if equal; -1 if the first is smaller than the second, otherwise 1
*/
int compare(void * data1, void * data2);
/*
purpose: to free all of the momory allocated to a file
parameters: the pointer to a file
returns: nothing
*/
void destroyFile(void * data);
/*
purpose: to add a new file into the specified tree
parameters: the pointer to the tree, a boolean specifing if it's a directory or file, a string of the path to the file
returns: nothing
*/
void addFileToTree(Tree * tree, bool isDir, char * path);
/*
purpose: to read all files and directories in the specified directory
parameters: the pointer to the tree, the string of the current directory
returns: true if files opened properly, otherwise false
*/
bool readDirectories(Tree * tree, char * dir);
/*
purpose: to rename a file
parameters: the new name, the old name, the pointer to the tree
returns: true if it was a successful renaming, otherwise false
*/
bool renameFile(char * newName, char * oldName, Tree * tree);
/*
purpose: to seperate the file name from the path
parameters: the full path including the file name
returns: an array of strings a[0] = path, a[1] = fileName
*/
char ** parsePath(char * path);
/*
purpose: to get a file from the tree
parameters: the specified path string, the pointer to the tree
returns: a file pointer to the file containing the specified path
*/
File * getFile(char * path, Tree * tree);
/*
purpose: to delete all files / subdirectories containing a specific string
parameters: the string to delete, the pointer to the tree
returns: nothing
*/
void deleteAllFilesContaining(char * dir, Tree * tree);
/*
purpose: to print out the path of any file containing the specified string
parameters: the tree pointer, the string to find
returns: nothing
*/
void findFile(Tree * tree, char * toFind);