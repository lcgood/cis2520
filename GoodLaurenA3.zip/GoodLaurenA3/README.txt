Author: Lauren Good 0871905
Project: Assignment 3
Course: CIS*2520
Last Modified: Aug 2, 2016

To Use:
(all steps to be done in the terminal window, in the current working directory)
	-to compile: type "make" onto the terminal
	-to run test: type "./bin/testRunnable" onto the terminal
	-to run program: type "./bin/a3runnable <baseDir>/" onto the terminal
		to open the current folder as the baseDir use "./"
		only subdirctories of the current directory can be accessed

Specifications:
	-Menu driven program. 
	-Enter the corresponding number for all menus

Limitations:
	-if "../" (or like term) is entered as the baseDir when starting the program, 
		all folders will be seen as files because of the lack of permissions.
	-you cannot rename to anything larger than 20 characters
	-if you move a directory, the subdirectories are not moved

Extensions:
	-when searching, it will find the term if it is contained in a larger string
		ex. Search '.c' will return 'main.c'
	-when changing names it is possible to change the name of a file in a subdirectory by:
		old name: full path name (ex. src/main.c)
		new name: just the file name (main.123)
	-"change directory" functionality was added to be able to print only the files in the current directory
	-"print" functionality was added for ease of use

References:

